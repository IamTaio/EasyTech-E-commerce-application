class API {
  static const allPosts = 'https://jsonplaceholder.typicode.com/posts';
  static const singlePost = 'https://jsonplaceholder.typicode.com/posts/';

  static const allUsers = 'https://jsonplaceholder.typicode.com/users';
  static const singleUser = 'https://jsonplaceholder.typicode.com/users/';
}