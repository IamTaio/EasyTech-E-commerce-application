class keyboard {
  String keyboardName;
  String manufacturer;
  String image;
  String price;
  String RGB;
  String modelNumber;
  String secondaryImage;

  keyboard({
    required this.keyboardName,
    required this.manufacturer,
    required this.image,
    required this.price,
    required this.RGB,
    required this.modelNumber,
    required this.secondaryImage,
  });
}