class headset {
  String headsetName;
  String manufacturer;
  String image;
  String secondaryImage;
  String price;
  String connectionType;
  String modelNumber;


  headset({
    required this.headsetName,
    required this.manufacturer,
    required this.image,
    required this.price,
    required this.connectionType,
    required this.modelNumber,
    required this.secondaryImage,
  });
}