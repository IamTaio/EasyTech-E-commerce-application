class tablet {
  String tabletName;
  String manufacturer;
  String image;
  String price;
  String storage;
  String modelNumber;

  tablet({
    required this.tabletName,
    required this.manufacturer,
    required this.image,
    required this.price,
    required this.storage,
    required this.modelNumber
  });

}