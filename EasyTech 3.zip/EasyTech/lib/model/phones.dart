class phone {
  String phoneName;
  String manufacturer;
  String image;
  String price;
  String storage;

  phone({
    required this.phoneName,
    required this.manufacturer,
    required this.image,
    required this.price,
    required this.storage,
  });

}