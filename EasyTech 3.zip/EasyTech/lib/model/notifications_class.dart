

class notificationClass{
  String bigName;
  String smallText;

  notificationClass({
    required this.bigName,
    required this.smallText,
  });

}