

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class categories {
  String CategoryName;
  String image;
  IconButton icon;



  categories({
    required this.CategoryName,
    required this.image,
    required this.icon,
  });

}