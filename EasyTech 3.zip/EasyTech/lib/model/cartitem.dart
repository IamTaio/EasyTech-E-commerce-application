class cartItem {
  String Name;
  String manufacturer;
  String image;
  String price;

  cartItem({
    required this.Name,
    required this.manufacturer,
    required this.image,
    required this.price,
  });

}